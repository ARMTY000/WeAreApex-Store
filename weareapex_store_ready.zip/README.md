WeAreApex - Render-ready store
--------------------------------

Quick start:

1. Copy project to your machine.
2. Create a .env file (see .env.example) and fill with your keys.
3. Install dependencies:
   npm install
4. Run locally:
   npm start
   -> open http://localhost:3000

Deploy to Render:
- Create a new Web Service, link repo or upload zip.
- Build command: npm install
- Start command: npm start
- Add environment variables from .env

Notes:
- Replace PayPal SDK client-id in public/index.html before going live.
- Use Stripe keys from dashboard (test keys while testing).
- Set ORDER_EMAIL to receive order notifications.
