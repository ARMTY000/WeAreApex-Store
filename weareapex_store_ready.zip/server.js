require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');
const paypal = require('@paypal/checkout-server-sdk');
const nodemailer = require('nodemailer');

const app = express();
app.use(express.static('public'));
app.use(bodyParser.json());

// load products
const products = JSON.parse(fs.readFileSync(path.join(__dirname,'public','products.json')));

// Stripe: create Checkout Session
app.post('/create-stripe-session', async (req, res) => {
  const { productId } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.json({ error: 'Product not found' });

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: product.name, metadata: { sku: product.sku } },
          unit_amount: product.price
        },
        quantity: 1
      }],
      success_url: (process.env.BASE_URL || 'https://example.com') + '/success.html?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: (process.env.BASE_URL || 'https://example.com') + '/cancel.html',
      metadata: { productId: product.id, sku: product.sku }
    });
    res.json({ sessionUrl: session.url });
  } catch (err) {
    console.error(err);
    res.json({ error: err.message });
  }
});

// Stripe webhook handler (use raw body verification in production)
app.post('/webhook/stripe', bodyParser.raw({type: 'application/json'}), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const productId = session.metadata?.productId;
    const product = products.find(p => p.id === productId);
    // send order email
    const email = session.customer_details?.email || session.customer_email;
    sendOrderEmail(email, product, session).catch(console.error);
  }

  res.json({ received: true });
});

// PayPal client
function paypalClient(){
  const env = new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID || '', process.env.PAYPAL_SECRET || '');
  return new paypal.core.PayPalHttpClient(env);
}

app.post('/create-paypal-order', async (req, res) => {
  const { productId } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.json({ error: 'Product not found' });

  const request = new paypal.orders.OrdersCreateRequest();
  request.prefer('return=representation');
  request.requestBody({
    intent: 'CAPTURE',
    purchase_units: [{
      amount: { currency_code: 'USD', value: (product.price/100).toFixed(2) },
      description: product.name,
      custom_id: product.id
    }]
  });

  try {
    const client = paypalClient();
    const order = await client.execute(request);
    res.json({ orderID: order.result.id });
  } catch (err) {
    console.error(err);
    res.json({ error: err.message });
  }
});

app.post('/capture-paypal-order', async (req, res) => {
  const { orderID } = req.body;
  try {
    const request = new paypal.orders.OrdersCaptureRequest(orderID);
    request.requestBody({});
    const client = paypalClient();
    const capture = await client.execute(request);
    const customId = capture.result.purchase_units?.[0]?.custom_id;
    const product = products.find(p => p.id === customId);
    const payerEmail = capture.result.payer?.email_address;
    if (product) sendOrderEmail(payerEmail, product, capture.result).catch(console.error);
    res.json({ success: true, capture: capture.result });
  } catch (err) {
    console.error(err);
    res.json({ error: err.message });
  }
});

// simple order email sender
async function sendOrderEmail(to, product, details){
  if (!to) {
    console.warn('No email for order - notify store owner instead.');
    to = process.env.ORDER_EMAIL || 'store@weareapex.com';
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.example.com',
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER || '',
      pass: process.env.SMTP_PASS || ''
    }
  });

  const html = `
    <h2>New order — ${product ? product.name : 'Unknown product'}</h2>
    <p>Customer: ${to}</p>
    <p>Product: ${product ? product.name : '—'}</p>
    <pre>${JSON.stringify(details,null,2)}</pre>
  `;

  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'WeAreApex <no-reply@weareapex.com>',
    to: process.env.ORDER_EMAIL || 'store@weareapex.com',
    subject: `New Order: ${product ? product.name : 'Order'}`,
    html
  });

  // also send the buyer a confirmation
  if (to && to.includes('@')) {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'WeAreApex <no-reply@weareapex.com>',
      to,
      subject: `Order confirmation — WeAreApex`,
      html: `<p>Thanks for your order of <strong>${product ? product.name : ''}</strong>. We'll email shipping details soon.</p>`
    });
  }
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
