// Minimal client for WeAreApex store
const API_BASE = '';

async function loadProducts(){
  const res = await fetch('/products.json');
  return res.json();
}
function formatPrice(cents){ return `$${(cents/100).toFixed(2)}`; }

function buildProductCard(p){
  const div = document.createElement('div');
  div.className = 'product';
  div.innerHTML = `
    <img src="${p.image || 'https://source.unsplash.com/600x400/?apparel'}" alt="${p.name}">
    <h3>${p.name}</h3>
    <p class="muted">${p.short}</p>
    <p>${formatPrice(p.price)}</p>
    <div>
      <button class="btn buy-stripe" data-id="${p.id}">Buy (Stripe)</button>
      <button class="small buy-paypal" data-id="${p.id}">Buy (PayPal)</button>
    </div>
  `;
  return div;
}

async function init(){
  const products = await loadProducts();
  const container = document.getElementById('products');
  products.forEach(p => container.appendChild(buildProductCard(p)));

  document.addEventListener('click', async (e) => {
    if (e.target.matches('.buy-stripe')){
      const productId = e.target.dataset.id;
      e.target.disabled = true;
      const res = await fetch('/create-stripe-session', {
        method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({productId})
      });
      const json = await res.json();
      if (json.error) { alert(json.error); e.target.disabled=false; return; }
      // redirect to Stripe Checkout
      window.location.href = json.sessionUrl;
    }

    if (e.target.matches('.buy-paypal')){
      const productId = e.target.dataset.id;
      const orderRes = await fetch('/create-paypal-order', {
        method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({productId})
      });
      const orderJson = await orderRes.json();
      if (orderJson.error) return alert(orderJson.error);
      const orderID = orderJson.orderID;
      // Render PayPal buttons in a modal container
      const container = document.getElementById('paypalButtonContainer');
      container.innerHTML = '';
      paypal.Buttons({
        createOrder: () => orderID,
        onApprove: async (data, actions) => {
          const capRes = await fetch('/capture-paypal-order', {
            method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({orderID})
          });
          const capJson = await capRes.json();
          if (capJson.error) return alert('Payment failed');
          alert('Thanks! Your order was received. Check your email for confirmation.');
        }
      }).render('#paypalButtonContainer');
    }
  });
}

init();
